import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  ArrowDownRight,
  CheckCircle2,
  Cpu,
  Layers,
  PackageCheck,
  RotateCcw,
  Search,
  Sparkles,
  Truck,
  XCircle,
} from "lucide-react";

import DashboardLayout from "../../layouts/DashboardLayout";
import ToastPopup, {
  type ToastType,
} from "../../components/common/ToastPopup";

import {
  getMyAllocationEquipmentDetails,
  getAllocationEquipmentDetails,
  handoverEquipmentDetail,
} from "../../services/allocationDetailService";

import {
  confirmEquipmentReturn,
  getEquipmentReturns,
  rejectEquipmentReturn,
  submitMyEquipmentReturn,
} from "../../services/equipmentReturnService";

import { getStoredRole } from "../../config/rolePermissions";

import type { AllocationEquipmentDetail } from "../../types/allocationDetail";
import type { EquipmentConditionLevel } from "../../types/equipmentInstance";
import type { EquipmentReturnRecord } from "../../types/equipmentReturn";

import "./EquipmentReturnPage.css";

import Pagination from "../../components/Pagination";
import usePagination from "../../hooks/usePagination";

type TabFilter =
  | "all"
  | "inuse"
  | "allocated"
  | "completed";

function formatDate(val?: string | null): string {
  if (!val) return "-";

  const d = new Date(val);

  return Number.isNaN(d.getTime())
    ? val
    : d.toLocaleDateString("vi-VN");
}

export default function EquipmentReturnPage() {
  const role = getStoredRole();

  const isManager =
    role === "Manager" || role === "Admin";

  const isFieldStaff =
    role === "Seasonal" ||
    role === "Technician" ||
    role === "Student";

  const [items, setItems] = useState<
    AllocationEquipmentDetail[]
  >([]);

  const [returnRecords, setReturnRecords] = useState<
    EquipmentReturnRecord[]
  >([]);

  const [
    submittedReturnIds,
    setSubmittedReturnIds,
  ] = useState<number[]>([]);

  const [loading, setLoading] = useState(true);

  const [searchTerm, setSearchTerm] =
    useState("");

  const [tabFilter, setTabFilter] =
    useState<TabFilter>("all");

  /* =========================================================
     ACTION MODALS
  ========================================================= */

  const [
    returnModalItem,
    setReturnModalItem,
  ] =
    useState<AllocationEquipmentDetail | null>(
      null
    );

  const [
    handoverModalItem,
    setHandoverModalItem,
  ] =
    useState<AllocationEquipmentDetail | null>(
      null
    );

  const [
    returnCondition,
    setReturnCondition,
  ] =
    useState<EquipmentConditionLevel>("Good");

  const [
    returnNotes,
    setReturnNotes,
  ] = useState("");

  const [
    damageDescription,
    setDamageDescription,
  ] = useState("");

  const [
    rejectReason,
    setRejectReason,
  ] = useState("");

  const [
    actionLoading,
    setActionLoading,
  ] = useState(false);

  /* =========================================================
     TOAST
  ========================================================= */

  const [toast, setToast] = useState<{
    visible: boolean;
    type: ToastType;
    title?: string;
    message: string;
  }>({
    visible: false,
    type: "error",
    message: "",
  });

  const showToast = (
    message: string,
    type: ToastType = "error",
    title?: string
  ) => {
    setToast({
      visible: true,
      type,
      title:
        title ||
        (type === "error"
          ? "Lỗi xử lý"
          : type === "success"
            ? "Thành công"
            : "Thông báo"),
      message,
    });
  };

  /* =========================================================
     LOAD DATA
  ========================================================= */

  const loadData = useCallback(async () => {
    try {
      setLoading(true);

      if (isManager) {
        /*
         * Manager vẫn sử dụng danh sách allocation
         * equipment hiện tại để giữ nguyên UI cũ.
         *
         * Đồng thời tải EquipmentReturns để biết
         * thiết bị nào thực sự đang chờ xác nhận trả.
         */
        const [
          allocationList,
          returns,
        ] = await Promise.all([
          getAllocationEquipmentDetails({
            size: 400,
          }),
          getEquipmentReturns({
            size: 400,
          }),
        ]);

        setItems(allocationList || []);
        setReturnRecords(returns || []);
      } else {
        /*
         * Seasonal / Technician / Student chỉ được
         * xem thiết bị được phân công cho chính mình.
         *
         * Không fallback sang endpoint global.
         */
        const list =
          await getMyAllocationEquipmentDetails({
            size: 400,
          });

        setItems(list || []);
      }
    } catch (err: any) {
      showToast(
        err?.response?.data?.message ||
          err?.message ||
          "Không thể tải danh sách thiết bị.",
        "error"
      );
    } finally {
      setLoading(false);
    }
  }, [isManager]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  /* =========================================================
     GET LATEST RETURN REQUEST FOR ALLOCATION
  ========================================================= */

  const getReturnForAllocation = useCallback(
    (
      allocationEquipmentDetailId: number
    ) => {
      const matches =
        returnRecords.filter(
          (record) =>
            record.allocationEquipmentDetailId ===
            allocationEquipmentDetailId
        );

      return matches.sort((a, b) => {
        const aTime = new Date(
          a.returnDate || 0
        ).getTime();

        const bTime = new Date(
          b.returnDate || 0
        ).getTime();

        return bTime - aTime;
      })[0];
    },
    [returnRecords]
  );

  /* =========================================================
     STATISTICS
  ========================================================= */

  const stats = useMemo(() => {
    const total = items.length;

    if (isManager) {
      const pendingIds = new Set(
        returnRecords
          .filter(
            (r) =>
              String(
                r.status || "Pending"
              ).toLowerCase() === "pending"
          )
          .map(
            (r) =>
              r.allocationEquipmentDetailId
          )
      );

      const confirmedIds = new Set(
        returnRecords
          .filter(
            (r) =>
              String(
                r.status || ""
              ).toLowerCase() === "confirmed"
          )
          .map(
            (r) =>
              r.allocationEquipmentDetailId
          )
      );

      const allocated = items.filter(
        (i) =>
          i.status === "Allocated" ||
          i.status === "Reserved" ||
          !i.status
      ).length;

      return {
        total,
        inUse: pendingIds.size,
        allocated,
        completed: confirmedIds.size,
      };
    }

    const inUse = items.filter(
      (i) =>
        i.status === "InUse" &&
        !submittedReturnIds.includes(
          i.allocationEquipmentDetailId
        )
    ).length;

    const allocated = items.filter(
      (i) =>
        i.status === "Allocated" ||
        i.status === "Reserved" ||
        !i.status
    ).length;

    const completed = items.filter(
      (i) =>
        i.status === "Completed" ||
        submittedReturnIds.includes(
          i.allocationEquipmentDetailId
        )
    ).length;

    return {
      total,
      inUse,
      allocated,
      completed,
    };
  }, [
    items,
    isManager,
    returnRecords,
    submittedReturnIds,
  ]);

  /* =========================================================
     FILTERING
  ========================================================= */

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const status =
        item.status || "Allocated";

      const returnRecord =
        getReturnForAllocation(
          item.allocationEquipmentDetailId
        );

      const returnStatus = String(
        returnRecord?.status || ""
      ).toLowerCase();

      const submittedLocally =
        submittedReturnIds.includes(
          item.allocationEquipmentDetailId
        );

      const matchesTab =
        tabFilter === "all" ||
        (tabFilter === "inuse" &&
          (isManager
            ? returnStatus === "pending"
            : status === "InUse" &&
              !submittedLocally)) ||
        (tabFilter === "allocated" &&
          (status === "Allocated" ||
            status === "Reserved")) ||
        (tabFilter === "completed" &&
          (isManager
            ? returnStatus === "confirmed"
            : status === "Completed" ||
              submittedLocally));

      if (!matchesTab) {
        return false;
      }

      if (!searchTerm.trim()) {
        return true;
      }

      const q =
        searchTerm.toLowerCase();

      const name = (
        item.allocatedEquipmentTypeName || ""
      ).toLowerCase();

      const instName = (
        item.equipmentInstanceName || ""
      ).toLowerCase();

      const code = (
        item.assetCode || ""
      ).toLowerCase();

      const serial = (
        item.serialNumber || ""
      ).toLowerCase();

      const exp = (
        item.experimentName || ""
      ).toLowerCase();

      const phase = (
        item.phaseName || ""
      ).toLowerCase();

      const returnNote = (
        returnRecord?.note || ""
      ).toLowerCase();

      return (
        name.includes(q) ||
        instName.includes(q) ||
        code.includes(q) ||
        serial.includes(q) ||
        exp.includes(q) ||
        phase.includes(q) ||
        returnNote.includes(q)
      );
    });
  }, [
    items,
    tabFilter,
    searchTerm,
    isManager,
    submittedReturnIds,
    getReturnForAllocation,
  ]);

  /* =========================================================
     HANDOVER EXECUTION
     Seasonal / Technician / Student
  ========================================================= */

  const handleConfirmHandover =
    async () => {
      if (!handoverModalItem) {
        return;
      }

      try {
        setActionLoading(true);

        await handoverEquipmentDetail(
          handoverModalItem.allocationEquipmentDetailId,
          {
            conditionBefore: "Good",
            note: null,
          }
        );

        showToast(
          `Đã tiếp nhận thiết bị "${
            handoverModalItem.equipmentInstanceName ||
            handoverModalItem.assetCode ||
            "thiết bị"
          }" vào sử dụng (InUse)!`,
          "success",
          "Tiếp nhận thiết bị thành công"
        );

        setHandoverModalItem(null);

        await loadData();
      } catch (err: any) {
        showToast(
          err?.response?.data?.message ||
            "Không thể tiếp nhận thiết bị.",
          "error"
        );
      } finally {
        setActionLoading(false);
      }
    };

  /* =========================================================
     RETURN / CONFIRM RETURN
  ========================================================= */

  const handleConfirmReturn =
    async () => {
      if (!returnModalItem) {
        return;
      }

      try {
        setActionLoading(true);

        /*
         * MANAGER:
         * xác nhận EquipmentReturn request.
         */
        if (isManager) {
          const returnRecord =
            getReturnForAllocation(
              returnModalItem.allocationEquipmentDetailId
            );

          if (
            !returnRecord?.equipmentReturnId
          ) {
            throw new Error(
              "Không tìm thấy yêu cầu trả thiết bị đang chờ xác nhận."
            );
          }

          await confirmEquipmentReturn(
            returnRecord.equipmentReturnId
          );

          showToast(
            `Đã xác nhận nghiệm thu và nhận thiết bị "${
              returnModalItem.equipmentInstanceName ||
              returnModalItem.assetCode ||
              "thiết bị"
            }" về kho.`,
            "success",
            "Xác nhận trả thiết bị thành công"
          );
        } else {
          /*
           * FIELD STAFF:
           * tạo EquipmentReturn request.
           */

          const isDamaged =
            returnCondition === "Broken" ||
            returnCondition ===
              "NeedMaintenance";

          await submitMyEquipmentReturn(
            returnModalItem.allocationEquipmentDetailId,
            {
              conditionAfter:
                returnCondition,

              isDamaged,

              damageDescription:
                isDamaged
                  ? damageDescription.trim() ||
                    returnNotes.trim() ||
                    null
                  : null,

              note:
                returnNotes.trim() ||
                null,
            }
          );

          /*
           * Cập nhật UI ngay sau khi API
           * trả thành công.
           */
          setSubmittedReturnIds(
            (prev) =>
              prev.includes(
                returnModalItem.allocationEquipmentDetailId
              )
                ? prev
                : [
                    ...prev,
                    returnModalItem.allocationEquipmentDetailId,
                  ]
          );

          showToast(
            `Đã gửi yêu cầu trả thiết bị "${
              returnModalItem.equipmentInstanceName ||
              returnModalItem.assetCode ||
              "thiết bị"
            }". Yêu cầu đang chờ quản lý xác nhận.`,
            "success",
            "Gửi trả thiết bị thành công"
          );
        }

        setReturnModalItem(null);
        setReturnNotes("");
        setDamageDescription("");
        setRejectReason("");

        await loadData();
      } catch (err: any) {
        showToast(
          err?.response?.data?.message ||
            err?.message ||
            "Không thể thực hiện thao tác hoàn trả.",
          "error"
        );
      } finally {
        setActionLoading(false);
      }
    };

  /* =========================================================
     MANAGER REJECT RETURN
  ========================================================= */

  const handleRejectReturn =
    async () => {
      if (
        !isManager ||
        !returnModalItem
      ) {
        return;
      }

      const returnRecord =
        getReturnForAllocation(
          returnModalItem.allocationEquipmentDetailId
        );

      if (
        !returnRecord?.equipmentReturnId
      ) {
        showToast(
          "Không tìm thấy yêu cầu trả thiết bị.",
          "error"
        );

        return;
      }

      if (!rejectReason.trim()) {
        showToast(
          "Vui lòng nhập lý do từ chối yêu cầu trả thiết bị.",
          "error"
        );

        return;
      }

      try {
        setActionLoading(true);

        await rejectEquipmentReturn(
          returnRecord.equipmentReturnId,
          {
            rejectionReason:
              rejectReason.trim(),
          }
        );

        showToast(
          "Đã từ chối yêu cầu trả thiết bị.",
          "success",
          "Đã cập nhật yêu cầu"
        );

        setReturnModalItem(null);
        setRejectReason("");

        await loadData();
      } catch (err: any) {
        showToast(
          err?.response?.data?.message ||
            "Không thể từ chối yêu cầu trả thiết bị.",
          "error"
        );
      } finally {
        setActionLoading(false);
      }
    };

  /* =========================================================
     PAGINATION
  ========================================================= */

  const {
    currentPage: currentPageList,
    pageSize: pageSizeList,
    paginatedItems: paginatedItemsList,
    setCurrentPage: setCurrentPageList,
    setPageSize: setPageSizeList,
  } = usePagination(
    filteredItems,
    10
  );

  /* =========================================================
     RENDER
  ========================================================= */

  return (
    <DashboardLayout>
      <div className="equipment-return-page">
        {/* =====================================================
            HEADER
        ===================================================== */}

        <header className="eq-return-header">
          <div>
            <p className="eq-return-breadcrumb">
              {isManager
                ? "Operations / Equipment Return Confirmation"
                : "Operations / Equipment Return"}
            </p>

            <h1>
              {isManager
                ? "Equipment Return Confirmation (Xác nhận trả thiết bị)"
                : "Equipment Handover & Return (Bàn giao & Trả thiết bị)"}
            </h1>

            <p className="eq-return-description">
              {isManager
                ? "Kiểm tra nghiệm thu và xác nhận tiếp nhận hoàn trả máy móc, thiết bị thực địa từ Kỹ thuật viên (Technician) và Thời vụ (Seasonal) về lại kho tài nguyên."
                : "Danh sách máy móc và trang thiết bị thực địa được phân bổ cho các ca làm việc và đề tài của bạn. Thực hiện tiếp nhận máy và gửi trả thiết bị sau khi hoàn thành nhiệm vụ."}
            </p>
          </div>
        </header>

        {/* =====================================================
            STATISTICS
        ===================================================== */}

        <div className="eq-return-stats-grid">
          <div className="eq-return-stat-card">
            <div className="eq-stat-icon-wrapper eq-stat-icon-all">
              <Cpu size={22} />
            </div>

            <div className="eq-stat-info">
              <span className="eq-stat-label">
                {isManager
                  ? "Tổng thiết bị phân bổ"
                  : "Tổng thiết bị được giao"}
              </span>

              <span className="eq-stat-value">
                {stats.total}
              </span>
            </div>
          </div>

          <div className="eq-return-stat-card">
            <div className="eq-stat-icon-wrapper eq-stat-icon-inuse">
              {isManager ? (
                <PackageCheck
                  size={22}
                />
              ) : (
                <RotateCcw
                  size={22}
                />
              )}
            </div>

            <div className="eq-stat-info">
              <span className="eq-stat-label">
                {isManager
                  ? "Yêu cầu trả đang chờ"
                  : "Đang sử dụng (Cần trả)"}
              </span>

              <span
                className="eq-stat-value"
                style={{
                  color: isManager
                    ? "#059669"
                    : "#dc2626",
                }}
              >
                {stats.inUse}
              </span>
            </div>
          </div>

          <div className="eq-return-stat-card">
            <div className="eq-stat-icon-wrapper eq-stat-icon-allocated">
              <Truck size={22} />
            </div>

            <div className="eq-stat-info">
              <span className="eq-stat-label">
                {isManager
                  ? "Chờ nhân viên nhận máy"
                  : "Chờ tiếp nhận máy"}
              </span>

              <span
                className="eq-stat-value"
                style={{
                  color: "#2563eb",
                }}
              >
                {stats.allocated}
              </span>
            </div>
          </div>

          <div className="eq-return-stat-card">
            <div className="eq-stat-icon-wrapper eq-stat-icon-completed">
              <CheckCircle2
                size={22}
              />
            </div>

            <div className="eq-stat-info">
              <span className="eq-stat-label">
                {isManager
                  ? "Đã nghiệm thu nhập kho"
                  : "Đã hoàn trả về kho"}
              </span>

              <span
                className="eq-stat-value"
                style={{
                  color: "#16a34a",
                }}
              >
                {stats.completed}
              </span>
            </div>
          </div>
        </div>

        {/* =====================================================
            SEARCH + FILTER
        ===================================================== */}

        <div className="eq-return-controls">
          <div className="eq-return-search-box">
            <Search
              className="eq-return-search-icon"
              size={17}
            />

            <input
              type="text"
              placeholder="Tìm theo tên máy, mã tài sản, số serial, đề tài, giai đoạn..."
              value={searchTerm}
              onChange={(e) =>
                setSearchTerm(
                  e.target.value
                )
              }
              className="eq-return-search-input"
            />
          </div>

          <div className="eq-return-filter-tabs">
            <button
              type="button"
              className={`eq-return-tab-btn ${
                tabFilter === "all"
                  ? "active"
                  : ""
              }`}
              onClick={() =>
                setTabFilter("all")
              }
            >
              Tất cả{" "}
              <span className="eq-tab-counter">
                {stats.total}
              </span>
            </button>

            <button
              type="button"
              className={`eq-return-tab-btn ${
                tabFilter === "inuse"
                  ? "active"
                  : ""
              }`}
              onClick={() =>
                setTabFilter("inuse")
              }
            >
              {isManager
                ? "Chờ xác nhận trả"
                : "Đang sử dụng (Cần trả)"}{" "}
              <span className="eq-tab-counter">
                {stats.inUse}
              </span>
            </button>

            <button
              type="button"
              className={`eq-return-tab-btn ${
                tabFilter ===
                "allocated"
                  ? "active"
                  : ""
              }`}
              onClick={() =>
                setTabFilter(
                  "allocated"
                )
              }
            >
              {isManager
                ? "Chờ giao máy"
                : "Chờ nhận máy"}{" "}
              <span className="eq-tab-counter">
                {stats.allocated}
              </span>
            </button>

            <button
              type="button"
              className={`eq-return-tab-btn ${
                tabFilter ===
                "completed"
                  ? "active"
                  : ""
              }`}
              onClick={() =>
                setTabFilter(
                  "completed"
                )
              }
            >
              {isManager
                ? "Đã nhập kho"
                : "Đã hoàn trả"}{" "}
              <span className="eq-tab-counter">
                {stats.completed}
              </span>
            </button>
          </div>
        </div>

        {/* =====================================================
            TABLE
        ===================================================== */}

        <div className="eq-return-table-card">
          {loading ? (
            <div className="eq-empty-state">
              <p>
                Đang tải danh sách
                thiết bị...
              </p>
            </div>
          ) : filteredItems.length ===
            0 ? (
            <div className="eq-empty-state">
              <Cpu
                size={40}
                color="#cbd5e1"
                style={{
                  margin:
                    "0 auto 12px",
                }}
              />

              <h3>
                Không tìm thấy thiết
                bị nào
              </h3>

              <p>
                Không có trang thiết
                bị nào phù hợp với bộ
                lọc hiện tại của bạn.
              </p>
            </div>
          ) : (
            <table className="eq-return-table">
              <thead>
                <tr>
                  <th>
                    Tên thiết bị & Mã
                    tài sản
                  </th>

                  <th>
                    Loại thiết bị
                  </th>

                  <th>
                    Đề tài & Giai đoạn
                  </th>

                  <th>
                    Thời hạn phân bổ
                  </th>

                  <th>
                    Trạng thái
                  </th>

                  <th
                    style={{
                      textAlign:
                        "right",
                    }}
                  >
                    {isManager
                      ? "Thao tác Quản lý"
                      : "Thao tác"}
                  </th>
                </tr>
              </thead>

              <tbody>
                {paginatedItemsList.map(
                  (item) => {
                    const status =
                      item.status ||
                      "Allocated";

                    const isAllocated =
                      status ===
                        "Allocated" ||
                      status ===
                        "Reserved";

                    const returnRecord =
                      getReturnForAllocation(
                        item.allocationEquipmentDetailId
                      );

                    const returnStatus =
                      String(
                        returnRecord?.status ||
                          ""
                      ).toLowerCase();

                    const hasPendingReturn =
                      returnStatus ===
                      "pending";

                    const hasConfirmedReturn =
                      returnStatus ===
                      "confirmed";

                    const submittedLocally =
                      submittedReturnIds.includes(
                        item.allocationEquipmentDetailId
                      );

                    const isInUse =
                      status ===
                        "InUse" &&
                      !submittedLocally;

                    const isCompleted =
                      status ===
                        "Completed" ||
                      hasConfirmedReturn ||
                      submittedLocally;

                    return (
                      <tr
                        key={
                          item.allocationEquipmentDetailId
                        }
                      >
                        <td>
                          <div className="eq-name-title">
                            {item.equipmentInstanceName ||
                              item.assetCode ||
                              "Máy thực địa"}
                          </div>

                          <div className="eq-asset-code">
                            Mã tài sản:{" "}
                            <strong>
                              {item.assetCode ||
                                "Chưa gán mã"}
                            </strong>

                            {item.serialNumber &&
                              ` • S/N: ${item.serialNumber}`}
                          </div>
                        </td>

                        <td>
                          {item.allocatedEquipmentTypeName ||
                            "Thiết bị tiêu chuẩn"}
                        </td>

                        <td>
                          <div className="eq-experiment-tag">
                            {item.experimentName ||
                              `Allocation #${item.allocationPlanId}`}
                          </div>

                          {item.phaseName && (
                            <div className="eq-phase-tag">
                              <Layers
                                size={
                                  11
                                }
                                style={{
                                  display:
                                    "inline",
                                  verticalAlign:
                                    "middle",
                                  marginRight: 3,
                                }}
                              />

                              {
                                item.phaseName
                              }
                            </div>
                          )}
                        </td>

                        <td>
                          {formatDate(
                            item.startDate
                          )}{" "}
                          →{" "}
                          {formatDate(
                            item.endDate
                          )}
                        </td>

                        <td>
                          {isManager &&
                          hasPendingReturn ? (
                            <span className="eq-badge eq-badge-inuse">
                              <RotateCcw
                                size={
                                  11
                                }
                              />{" "}
                              Chờ xác nhận
                              trả
                            </span>
                          ) : isInUse ? (
                            <span className="eq-badge eq-badge-inuse">
                              <Sparkles
                                size={
                                  11
                                }
                              />{" "}
                              Đang sử dụng
                            </span>
                          ) : isCompleted ? (
                            <span className="eq-badge eq-badge-completed">
                              <CheckCircle2
                                size={
                                  11
                                }
                              />{" "}
                              {isManager
                                ? "Đã nhập kho"
                                : "Đã hoàn trả"}
                            </span>
                          ) : (
                            <span className="eq-badge eq-badge-allocated">
                              <Truck
                                size={
                                  11
                                }
                              />{" "}
                              Chờ nhận máy
                            </span>
                          )}
                        </td>

                        <td
                          style={{
                            textAlign:
                              "right",
                          }}
                        >
                          {/* ALLOCATED */}

                          {isAllocated &&
                            (isManager ? (
                              <span
                                style={{
                                  fontSize:
                                    "11.5px",
                                  color:
                                    "#64748b",
                                }}
                              >
                                Chờ nhân viên
                                nhận
                              </span>
                            ) : (
                              <button
                                type="button"
                                className="eq-btn-handover"
                                onClick={() =>
                                  setHandoverModalItem(
                                    item
                                  )
                                }
                                title="Xác nhận tiếp nhận thiết bị vào ca làm việc"
                              >
                                <ArrowDownRight
                                  size={
                                    13
                                  }
                                />{" "}
                                Nhận thiết bị
                              </button>
                            ))}

                          {/* IN USE / PENDING RETURN */}

                          {(isInUse ||
                            (isManager &&
                              hasPendingReturn)) &&
                            (isManager ? (
                              hasPendingReturn ? (
                                <button
                                  type="button"
                                  className="eq-btn-confirm-return"
                                  onClick={() => {
                                    setReturnModalItem(
                                      item
                                    );

                                    setReturnCondition(
                                      "Good"
                                    );

                                    setReturnNotes(
                                      ""
                                    );

                                    setDamageDescription(
                                      ""
                                    );

                                    setRejectReason(
                                      ""
                                    );
                                  }}
                                  title="Manager xác nhận nghiệm thu và tiếp nhận máy về kho"
                                >
                                  <PackageCheck
                                    size={
                                      13
                                    }
                                  />{" "}
                                  Xử lý yêu
                                  cầu trả
                                </button>
                              ) : (
                                <span
                                  style={{
                                    fontSize:
                                      "11.5px",
                                    color:
                                      "#64748b",
                                  }}
                                >
                                  Chờ nhân
                                  viên gửi
                                  trả
                                </span>
                              )
                            ) : (
                              <button
                                type="button"
                                className="eq-btn-return"
                                onClick={() => {
                                  setReturnModalItem(
                                    item
                                  );

                                  setReturnCondition(
                                    "Good"
                                  );

                                  setReturnNotes(
                                    ""
                                  );

                                  setDamageDescription(
                                    ""
                                  );

                                  setRejectReason(
                                    ""
                                  );
                                }}
                                title="Nhân viên gửi trả thiết bị về kho sau ca làm việc"
                              >
                                <RotateCcw
                                  size={
                                    13
                                  }
                                />{" "}
                                Trả thiết bị
                              </button>
                            ))}

                          {/* COMPLETED */}

                          {isCompleted && (
                            <span
                              style={{
                                fontSize:
                                  "11.5px",
                                color:
                                  "#94a3b8",
                              }}
                            >
                              {isManager
                                ? "Đã nhập kho"
                                : "Hoàn tất"}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>
          )}

          {!loading &&
            filteredItems.length >
              0 && (
              <Pagination
                currentPage={
                  currentPageList
                }
                totalItems={
                  filteredItems.length
                }
                pageSize={
                  pageSizeList
                }
                onPageChange={
                  setCurrentPageList
                }
                onPageSizeChange={
                  setPageSizeList
                }
              />
            )}
        </div>

        {/* =====================================================
            HANDOVER MODAL
        ===================================================== */}

        {handoverModalItem && (
          <div
            className="eq-modal-backdrop"
            onClick={() =>
              !actionLoading &&
              setHandoverModalItem(
                null
              )
            }
          >
            <div
              className="eq-modal-card"
              onClick={(e) =>
                e.stopPropagation()
              }
            >
              <div className="eq-modal-header">
                <h3>
                  <PackageCheck
                    size={18}
                    color="#16a34a"
                  />{" "}
                  Tiếp nhận thiết bị
                  vào ca làm việc
                </h3>

                <button
                  type="button"
                  className="eq-modal-close-btn"
                  onClick={() =>
                    !actionLoading &&
                    setHandoverModalItem(
                      null
                    )
                  }
                >
                  <XCircle
                    size={18}
                  />
                </button>
              </div>

              <div className="eq-modal-body">
                <p
                  style={{
                    margin:
                      "0 0 10px",
                    color: "#334155",
                  }}
                >
                  Bạn đang xác nhận
                  tiếp nhận máy móc để
                  phục vụ nhiệm vụ
                  thực địa:
                </p>

                <div className="eq-modal-info-box">
                  <div className="eq-modal-info-row">
                    <span>
                      Tên thiết bị:
                    </span>

                    <strong>
                      {handoverModalItem.equipmentInstanceName ||
                        "Máy thực địa"}
                    </strong>
                  </div>

                  <div className="eq-modal-info-row">
                    <span>
                      Mã tài sản:
                    </span>

                    <strong>
                      {handoverModalItem.assetCode ||
                        "N/A"}
                    </strong>
                  </div>

                  <div className="eq-modal-info-row">
                    <span>
                      Đề tài / Giai
                      đoạn:
                    </span>

                    <strong>
                      {handoverModalItem.experimentName ||
                        `Plan #${handoverModalItem.allocationPlanId}`}
                    </strong>
                  </div>

                  <div className="eq-modal-info-row">
                    <span>
                      Thời hạn phân bổ:
                    </span>

                    <strong>
                      {formatDate(
                        handoverModalItem.startDate
                      )}{" "}
                      →{" "}
                      {formatDate(
                        handoverModalItem.endDate
                      )}
                    </strong>
                  </div>
                </div>

                <div
                  style={{
                    background:
                      "#f0fdf4",
                    border:
                      "1px solid #bbf7d0",
                    padding:
                      "10px 12px",
                    borderRadius:
                      "8px",
                    fontSize:
                      "12.5px",
                    color:
                      "#166534",
                  }}
                >
                  💡 Sau khi nhận máy,
                  trạng thái thiết bị
                  sẽ chuyển sang{" "}
                  <strong>
                    In Use (Đang sử
                    dụng)
                  </strong>
                  .
                </div>
              </div>

              <div className="eq-modal-footer">
                <button
                  type="button"
                  className="eq-modal-btn-cancel"
                  onClick={() =>
                    setHandoverModalItem(
                      null
                    )
                  }
                  disabled={
                    actionLoading
                  }
                >
                  Hủy
                </button>

                <button
                  type="button"
                  className="eq-modal-btn-handover"
                  onClick={() =>
                    void handleConfirmHandover()
                  }
                  disabled={
                    actionLoading
                  }
                >
                  {actionLoading
                    ? "Đang xử lý..."
                    : "Xác nhận nhận thiết bị"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* =====================================================
            RETURN MODAL
        ===================================================== */}

        {returnModalItem && (
          <div
            className="eq-modal-backdrop"
            onClick={() =>
              !actionLoading &&
              setReturnModalItem(
                null
              )
            }
          >
            <div
              className="eq-modal-card"
              onClick={(e) =>
                e.stopPropagation()
              }
            >
              <div className="eq-modal-header">
                <h3>
                  {isManager ? (
                    <>
                      <PackageCheck
                        size={18}
                        color="#16a34a"
                      />{" "}
                      Xác nhận Nghiệm
                      thu & Nhận trả
                      thiết bị về kho
                    </>
                  ) : (
                    <>
                      <RotateCcw
                        size={18}
                        color="#dc2626"
                      />{" "}
                      Bàn giao trả
                      thiết bị sau khi
                      sử dụng
                    </>
                  )}
                </h3>

                <button
                  type="button"
                  className="eq-modal-close-btn"
                  onClick={() =>
                    !actionLoading &&
                    setReturnModalItem(
                      null
                    )
                  }
                >
                  <XCircle
                    size={18}
                  />
                </button>
              </div>

              <div className="eq-modal-body">
                <p
                  style={{
                    margin:
                      "0 0 10px",
                    color: "#334155",
                  }}
                >
                  {isManager
                    ? "Quản lý / Thủ kho thực hiện kiểm tra nghiệm thu tình trạng máy khi thu hồi về kho:"
                    : "Bàn giao hoàn trả thiết bị từ thực địa về lại cho Quản lý / Kho thiết bị:"}
                </p>

                <div className="eq-modal-info-box">
                  <div className="eq-modal-info-row">
                    <span>
                      Tên thiết bị:
                    </span>

                    <strong>
                      {returnModalItem.equipmentInstanceName ||
                        "Máy thực địa"}
                    </strong>
                  </div>

                  <div className="eq-modal-info-row">
                    <span>
                      Mã tài sản:
                    </span>

                    <strong>
                      {returnModalItem.assetCode ||
                        "N/A"}
                    </strong>
                  </div>

                  <div className="eq-modal-info-row">
                    <span>
                      Trạng thái hiện
                      tại:
                    </span>

                    <strong
                      style={{
                        color:
                          "#059669",
                      }}
                    >
                      {isManager
                        ? getReturnForAllocation(
                            returnModalItem.allocationEquipmentDetailId
                          )
                            ?.status ||
                          "Pending"
                        : "In Use (Đang sử dụng)"}
                    </strong>
                  </div>
                </div>

                {/* MANAGER VIEW */}

                {isManager ? (
                  <>
                    <div className="eq-modal-info-box">
                      <div className="eq-modal-info-row">
                        <span>
                          Tình trạng khi
                          trả:
                        </span>

                        <strong>
                          {getReturnForAllocation(
                            returnModalItem.allocationEquipmentDetailId
                          )
                            ?.conditionAfter ||
                            "-"}
                        </strong>
                      </div>

                      <div className="eq-modal-info-row">
                        <span>
                          Hư hỏng:
                        </span>

                        <strong>
                          {getReturnForAllocation(
                            returnModalItem.allocationEquipmentDetailId
                          )
                            ?.isDamaged
                            ? "Có"
                            : "Không"}
                        </strong>
                      </div>

                      <div className="eq-modal-info-row">
                        <span>
                          Mô tả hư hỏng:
                        </span>

                        <strong>
                          {getReturnForAllocation(
                            returnModalItem.allocationEquipmentDetailId
                          )
                            ?.damageDescription ||
                            "-"}
                        </strong>
                      </div>

                      <div className="eq-modal-info-row">
                        <span>
                          Ghi chú người
                          trả:
                        </span>

                        <strong>
                          {getReturnForAllocation(
                            returnModalItem.allocationEquipmentDetailId
                          )
                            ?.note ||
                            "-"}
                        </strong>
                      </div>
                    </div>

                    <div className="eq-modal-field">
                      <label>
                        Lý do từ chối
                        (chỉ cần nhập
                        khi từ chối):
                      </label>

                      <textarea
                        rows={3}
                        placeholder="Nhập lý do nếu yêu cầu trả chưa thể được xác nhận..."
                        value={
                          rejectReason
                        }
                        onChange={(e) =>
                          setRejectReason(
                            e.target
                              .value
                          )
                        }
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {/* FIELD STAFF VIEW */}

                    <div className="eq-modal-field">
                      <label>
                        Tình trạng thiết
                        bị khi trả:
                      </label>

                      <select
                        value={
                          returnCondition
                        }
                        onChange={(e) =>
                          setReturnCondition(
                            e.target
                              .value as EquipmentConditionLevel
                          )
                        }
                      >
                        <option value="Good">
                          Hoạt động tốt
                          (Good)
                        </option>

                        <option value="Normal">
                          Bình thường
                          (Normal)
                        </option>

                        <option value="NeedMaintenance">
                          Cần bảo dưỡng
                          (Need
                          Maintenance)
                        </option>

                        <option value="Broken">
                          Hỏng hóc / Cần
                          sửa chữa
                          (Broken)
                        </option>
                      </select>
                    </div>

                    {(returnCondition ===
                      "Broken" ||
                      returnCondition ===
                        "NeedMaintenance") && (
                      <div className="eq-modal-field">
                        <label>
                          Mô tả hư hỏng
                          / vấn đề:
                        </label>

                        <textarea
                          rows={3}
                          placeholder="Mô tả cụ thể lỗi, hư hỏng hoặc nhu cầu bảo dưỡng..."
                          value={
                            damageDescription
                          }
                          onChange={(
                            e
                          ) =>
                            setDamageDescription(
                              e.target
                                .value
                            )
                          }
                        />
                      </div>
                    )}

                    <div className="eq-modal-field">
                      <label>
                        Ghi chú bàn giao
                        trả:
                      </label>

                      <textarea
                        rows={3}
                        placeholder="Ghi nhận tình trạng pin, phụ kiện, vệ sinh máy, sự cố phát sinh..."
                        value={
                          returnNotes
                        }
                        onChange={(e) =>
                          setReturnNotes(
                            e.target
                              .value
                          )
                        }
                      />
                    </div>
                  </>
                )}

                {/* INFO BOX */}

                <div
                  style={{
                    background:
                      isManager
                        ? "#f0fdf4"
                        : "#fef2f2",

                    border: `1px solid ${
                      isManager
                        ? "#bbf7d0"
                        : "#fecaca"
                    }`,

                    padding:
                      "10px 12px",

                    borderRadius:
                      "8px",

                    fontSize:
                      "12.5px",

                    color:
                      isManager
                        ? "#166534"
                        : "#991b1b",
                  }}
                >
                  {isManager ? (
                    <>
                      💡 Chỉ xác nhận khi
                      đã kiểm tra thực
                      tế thiết bị.
                      Backend sẽ hoàn
                      tất quy trình
                      Equipment Return
                      và cập nhật trạng
                      thái liên quan.
                    </>
                  ) : (
                    <>
                      ⚠️ Thao tác này sẽ{" "}
                      <strong>
                        gửi yêu cầu trả
                        thiết bị
                      </strong>
                      . Thiết bị chỉ
                      hoàn tất quy
                      trình trả sau khi
                      Manager xác nhận.
                    </>
                  )}
                </div>
              </div>

              {/* FOOTER */}

              <div className="eq-modal-footer">
                <button
                  type="button"
                  className="eq-modal-btn-cancel"
                  onClick={() =>
                    setReturnModalItem(
                      null
                    )
                  }
                  disabled={
                    actionLoading
                  }
                >
                  Hủy
                </button>

                {isManager && (
                  <button
                    type="button"
                    className="eq-modal-btn-cancel"
                    onClick={() =>
                      void handleRejectReturn()
                    }
                    disabled={
                      actionLoading
                    }
                  >
                    <XCircle
                      size={15}
                    />{" "}
                    Từ chối yêu cầu
                  </button>
                )}

                <button
                  type="button"
                  className={
                    isManager
                      ? "eq-modal-btn-handover"
                      : "eq-modal-btn-confirm"
                  }
                  onClick={() =>
                    void handleConfirmReturn()
                  }
                  disabled={
                    actionLoading
                  }
                >
                  {actionLoading ? (
                    "Đang xử lý..."
                  ) : isManager ? (
                    <>
                      <CheckCircle2
                        size={15}
                      />{" "}
                      Xác nhận trả thiết
                      bị
                    </>
                  ) : (
                    <>
                      <RotateCcw
                        size={15}
                      />{" "}
                      Gửi yêu cầu trả
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* =====================================================
            GLOBAL TOAST
        ===================================================== */}

        <ToastPopup
          visible={toast.visible}
          type={toast.type}
          title={toast.title}
          message={toast.message}
          onClose={() =>
            setToast((prev) => ({
              ...prev,
              visible: false,
            }))
          }
        />
      </div>
    </DashboardLayout>
  );
}