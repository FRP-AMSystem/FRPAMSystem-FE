import {
  useEffect,
  useMemo,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";

import {
  createAllocationEquipmentDetail,
} from "../../services/allocationDetailService";

import {
  getExperimentEquipmentRequirements,
} from "../../services/experimentEquipmentRequirementService";

import type {
  AllocationDetailStatus,
} from "../../types/allocationDetail";

import type {
  ExperimentEquipmentRequirement,
} from "../../types/experimentEquipmentRequirement";

import "./AllocationResourceForm.css";

interface AddEquipmentResourceFormProps {
  allocationPlanId: number;
  experimentId: number;
  onCreated: () => void | Promise<void>;
  onCancel: () => void;
}

interface FormState {
  expEquipmentReqId: string;
  quantity: string;
  isSubstitute: boolean;
  efficiencyRate: string;
  startDate: string;
  endDate: string;
  status: AllocationDetailStatus;
}

function getErrorMessage(error: unknown): string {
  if (
    typeof error === "object" &&
    error !== null &&
    "response" in error
  ) {
    const response = (
      error as {
        response?: {
          data?: {
            message?: string;
            title?: string;
            errors?: Record<string, string[]>;
          };
        };
      }
    ).response;

    if (response?.data?.message) {
      return response.data.message;
    }

    if (response?.data?.errors) {
      return Object.values(response.data.errors)
        .flat()
        .join(" ");
    }

    if (response?.data?.title) {
      return response.data.title;
    }
  }

  if (error instanceof Error) {
    return error.message;
  }

  return "Cannot create equipment allocation.";
}

function normalizeEfficiencyToPercent(
  value?: number | null
): number {
  if (value === null || value === undefined) {
    return 100;
  }

  return value <= 1 ? value * 100 : value;
}

function toDateTimePayload(
  value: string,
  endOfDay = false
): string {
  if (!value) {
    return "";
  }

  return endOfDay
    ? `${value}T23:59:59`
    : `${value}T00:00:00`;
}

export default function AddEquipmentResourceForm({
  allocationPlanId,
  experimentId,
  onCreated,
  onCancel,
}: AddEquipmentResourceFormProps) {
  const [requirements, setRequirements] = useState<
    ExperimentEquipmentRequirement[]
  >([]);

  const [form, setForm] = useState<FormState>({
    expEquipmentReqId: "",
    quantity: "1",
    isSubstitute: false,
    efficiencyRate: "100",
    startDate: "",
    endDate: "",
    status: "Proposed",
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const selectedRequirement = useMemo(
    () =>
      requirements.find(
        (requirement) =>
          requirement.expEquipmentReqId ===
          Number(form.expEquipmentReqId)
      ),
    [requirements, form.expEquipmentReqId]
  );

  useEffect(() => {
    async function loadRequirements() {
      if (
        !Number.isInteger(allocationPlanId) ||
        allocationPlanId <= 0 ||
        !Number.isInteger(experimentId) ||
        experimentId <= 0
      ) {
        setError(
          "Allocation plan or experiment ID is invalid."
        );
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");

        const data =
          await getExperimentEquipmentRequirements({
            experimentId,
            page: 1,
            size: 100,
          });

        setRequirements(
          Array.isArray(data) ? data : []
        );
      } catch (loadError) {
        console.error(
          "Load equipment requirements failed:",
          loadError
        );
        setError(getErrorMessage(loadError));
        setRequirements([]);
      } finally {
        setLoading(false);
      }
    }

    void loadRequirements();
  }, [allocationPlanId, experimentId]);

  const handleInputChange = (
    event: ChangeEvent<
      HTMLInputElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = event.target;

    setForm((current) => ({
      ...current,
      [name]: value,
    }));
  };

  const handleCheckboxChange = (
    event: ChangeEvent<HTMLInputElement>
  ) => {
    const { name, checked } = event.target;

    setForm((current) => ({
      ...current,
      [name]: checked,
    }));
  };

  const handleSubmit = async (
    event: FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();
    setError("");

    if (!selectedRequirement) {
      setError(
        "Please select an equipment requirement."
      );
      return;
    }

    const quantity = Number(form.quantity);
    const efficiencyPercent = Number(
      form.efficiencyRate
    );

    if (
      !Number.isInteger(quantity) ||
      quantity <= 0
    ) {
      setError(
        "Quantity must be a positive integer."
      );
      return;
    }

    if (quantity > selectedRequirement.quantity) {
      setError(
        `Quantity cannot exceed ${selectedRequirement.quantity}.`
      );
      return;
    }

    if (
      !Number.isFinite(efficiencyPercent) ||
      efficiencyPercent < 0 ||
      efficiencyPercent > 100
    ) {
      setError(
        "Efficiency rate must be between 0 and 100."
      );
      return;
    }

    const minimumEfficiency =
      normalizeEfficiencyToPercent(
        selectedRequirement.minAcceptableEfficiency
      );

    if (efficiencyPercent < minimumEfficiency) {
      setError(
        `Efficiency rate must be at least ${minimumEfficiency}%.`
      );
      return;
    }

    if (!form.startDate || !form.endDate) {
      setError(
        "Please select start and end dates."
      );
      return;
    }

    const startDate = new Date(form.startDate);
    const endDate = new Date(form.endDate);

    if (
      Number.isNaN(startDate.getTime()) ||
      Number.isNaN(endDate.getTime())
    ) {
      setError("Allocation dates are invalid.");
      return;
    }

    if (endDate <= startDate) {
      setError(
        "End date must be after start date."
      );
      return;
    }

    if (
      form.isSubstitute &&
      !selectedRequirement.allowSubstitute
    ) {
      setError(
        "This requirement does not allow substitute equipment."
      );
      return;
    }

    try {
      setSaving(true);

      await createAllocationEquipmentDetail({
        allocationPlanId,
        expEquipmentReqId:
          selectedRequirement.expEquipmentReqId,
        phaseEquipmentReqId: null,
        allocatedEquipmentTypeId:
          selectedRequirement.equipmentTypeId,
        equipmentInstanceId: null,
        quantity,
        efficiencyRate:
          efficiencyPercent / 100,
        isSubstitute: form.isSubstitute,

        startDate: toDateTimePayload(
          form.startDate
        ),

        endDate: toDateTimePayload(
          form.endDate,
          true
        ),

        status: form.status,
      });

      await onCreated();
    } catch (submitError) {
      console.error(
        "Create equipment allocation failed:",
        submitError
      );
      setError(getErrorMessage(submitError));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="resource-form-card">
        Loading equipment requirements...
      </div>
    );
  }

  return (
    <form
      className="resource-form-grid"
      onSubmit={handleSubmit}
    >
      {error && (
        <div className="resource-form-error">
          {error}
        </div>
      )}

      <section className="resource-form-card">
        <h2>Equipment Information</h2>

        <label htmlFor="expEquipmentReqId">
          Equipment Requirement
        </label>

        <select
          id="expEquipmentReqId"
          name="expEquipmentReqId"
          value={form.expEquipmentReqId}
          onChange={handleInputChange}
          required
        >
          <option value="">
            Select requirement
          </option>

          {requirements.map((requirement) => (
            <option
              key={requirement.expEquipmentReqId}
              value={requirement.expEquipmentReqId}
            >
              #{requirement.expEquipmentReqId} -{" "}
              {requirement.equipmentTypeName ||
                `Equipment type #${requirement.equipmentTypeId}`}{" "}
              - Quantity: {requirement.quantity}
            </option>
          ))}
        </select>

        {requirements.length === 0 && (
          <small>
            This experiment has no equipment
            requirements.
          </small>
        )}

        <small>
          Equipment is allocated by quantity because
          the current service does not expose equipment
          instance endpoints.
        </small>

        <label htmlFor="quantity">
          Quantity
        </label>

        <input
          id="quantity"
          type="number"
          name="quantity"
          min="1"
          max={selectedRequirement?.quantity}
          value={form.quantity}
          onChange={handleInputChange}
          required
        />

        <label className="resource-checkbox">
          <input
            type="checkbox"
            name="isSubstitute"
            checked={form.isSubstitute}
            onChange={handleCheckboxChange}
            disabled={
              !selectedRequirement?.allowSubstitute
            }
          />

          <div>
            <strong>
              Use substitute equipment
            </strong>

            <small>
              Use another equipment type only when the
              required equipment is unavailable.
            </small>
          </div>
        </label>

        <label htmlFor="efficiencyRate">
          Efficiency Rate (%)
        </label>

        <input
          id="efficiencyRate"
          type="number"
          name="efficiencyRate"
          min="0"
          max="100"
          step="0.01"
          value={form.efficiencyRate}
          onChange={handleInputChange}
          required
        />
      </section>

      <section className="resource-form-card">
        <h2>Allocation Period</h2>

        <label htmlFor="startDate">
          Start Date
        </label>

        <input
          id="startDate"
          type="date"
          name="startDate"
          value={form.startDate}
          onChange={handleInputChange}
          onClick={(event) => {
            const input = event.currentTarget as HTMLInputElement & {
              showPicker?: () => void;
            };

            input.showPicker?.();
          }}
          required
        />

        <label htmlFor="endDate">
          End Date
        </label>

        <input
          id="endDate"
          type="date"
          name="endDate"
          value={form.endDate}
          min={form.startDate || undefined}
          onChange={handleInputChange}
          onClick={(event) => {
            const input = event.currentTarget as HTMLInputElement & {
              showPicker?: () => void;
            };

            input.showPicker?.();
          }}
          required
        />

        <label htmlFor="status">
          Initial Status
        </label>

        <select
          id="status"
          name="status"
          value={form.status}
          onChange={handleInputChange}
        >
          <option value="Proposed">
            Proposed
          </option>
          <option value="Reserved">
            Reserved
          </option>
        </select>

        <div className="resource-preview">
          <div>
            <span>Allocation Plan</span>
            <strong>#{allocationPlanId}</strong>
          </div>

          <div>
            <span>Requirement</span>
            <strong>
              {selectedRequirement
                ? `#${selectedRequirement.expEquipmentReqId}`
                : "-"}
            </strong>
          </div>

          <div>
            <span>Equipment Type</span>
            <strong>
              {selectedRequirement?.equipmentTypeName ||
                "-"}
            </strong>
          </div>

          <div>
            <span>Minimum Efficiency</span>
            <strong>
              {selectedRequirement
                ? `${normalizeEfficiencyToPercent(
                  selectedRequirement.minAcceptableEfficiency
                )}%`
                : "-"}
            </strong>
          </div>
        </div>

        <div className="resource-form-actions">
          <button
            type="button"
            className="resource-cancel-button"
            onClick={onCancel}
            disabled={saving}
          >
            Cancel
          </button>

          <button
            type="submit"
            className="resource-save-button"
            disabled={
              saving ||
              requirements.length === 0
            }
          >
            {saving
              ? "Adding..."
              : "Add Equipment"}
          </button>
        </div>
      </section>
    </form>
  );
}
