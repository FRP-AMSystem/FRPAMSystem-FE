import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import DashboardLayout from "../../layouts/DashboardLayout";

import { getExperiments } from "../../services/experimentService";
import { getEquipmentTypes } from "../../services/equipmentService";

import {
  getExperimentEquipmentRequirementById,
  updateExperimentEquipmentRequirement,
} from "../../services/experimentEquipmentRequirementService";

import type { ExperimentResponse } from "../../types/experiment";
import type { EquipmentType } from "../../types/equipment";

import "./RequirementForm.css";


function isDraftExperimentStatus(
  status?: string | null
): boolean {
  return (
    status === "Draft" ||
    status === "Created"
  );
}

export default function EditRequirement() {
  const navigate = useNavigate();
  const { id } = useParams();

  const requirementId = Number(id);

  const [experiments, setExperiments] = useState<ExperimentResponse[]>([]);
  const [equipmentTypes, setEquipmentTypes] = useState<EquipmentType[]>([]);

  const [form, setForm] = useState({
    experimentId: "",
    equipmentTypeId: "",
    quantity: "1",
    allowSubstitute: "true",
    minAcceptableEfficiency: "80",
    note: "",
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [error, setError] = useState("");

  const selectedExperiment = useMemo(() => {
    return experiments.find(
      (item) => item.experimentId === Number(form.experimentId)
    );
  }, [experiments, form.experimentId]);

  const selectedEquipmentType = useMemo(() => {
    return equipmentTypes.find(
      (item) => item.equipmentTypeId === Number(form.equipmentTypeId)
    );
  }, [equipmentTypes, form.equipmentTypeId]);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);

        const [requirementData, experimentData, equipmentTypeData] =
          await Promise.all([
            getExperimentEquipmentRequirementById(requirementId),
            getExperiments(),
            getEquipmentTypes(),
          ]);

        setExperiments(experimentData);
        setEquipmentTypes(equipmentTypeData);

        setForm({
          experimentId: String(requirementData.experimentId || ""),
          equipmentTypeId: String(requirementData.equipmentTypeId || ""),
          quantity: String(requirementData.quantity || "1"),
          allowSubstitute: String(requirementData.allowSubstitute ?? true),
          minAcceptableEfficiency: String(
            requirementData.minAcceptableEfficiency ?? "80"
          ),
          note: requirementData.note || "",
        });
      } catch (err) {
        console.error(err);
        setError("Cannot load requirement information.");
      } finally {
        setLoading(false);
      }
    }

    if (requirementId) {
      loadData();
    }
  }, [requirementId]);

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!form.experimentId) {
      setError("Please select an experiment.");
      return;
    }

    if (
      !selectedExperiment ||
      !isDraftExperimentStatus(
        selectedExperiment.status
      )
    ) {
      setError(
        "Requirements can only be edited while the experiment is in Draft status."
      );
      return;
    }

    if (!form.equipmentTypeId) {
      setError("Please select an equipment type.");
      return;
    }

    if (Number(form.quantity) <= 0) {
      setError("Quantity must be greater than 0.");
      return;
    }

    try {
      setSaving(true);

      await updateExperimentEquipmentRequirement(requirementId, {
        experimentId: Number(form.experimentId),
        equipmentTypeId: Number(form.equipmentTypeId),
        quantity: Number(form.quantity),
        allowSubstitute: form.allowSubstitute === "true",
        minAcceptableEfficiency: Number(form.minAcceptableEfficiency),
        note: form.note,
      });

      navigate("/equipment-requirements");
    } catch (err) {
      console.error(err);
      setError("Update equipment requirement failed.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="requirement-form-page">
          <p>Loading requirement...</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="requirement-form-page">
        <div className="requirement-form-header">
          <div>
            <p className="breadcrumb">
              Dashboard / Equipment Requirements / Edit
            </p>

            <h1>Edit Equipment Requirement</h1>

            <span>
              Update equipment requirement information for the selected
              experiment.
            </span>
          </div>

          <button
            type="button"
            className="back-btn"
            onClick={() => navigate("/equipment-requirements")}
          >
            Back
          </button>
        </div>

        {error && <div className="form-error">{error}</div>}

        <form className="requirement-form-grid" onSubmit={handleSubmit}>
          <div className="requirement-form-card">
            <h3>Requirement Information</h3>

            <label>Experiment</label>
            <select
              name="experimentId"
              value={form.experimentId}
              onChange={handleChange}
              required
              disabled
            >
              <option value="">Select experiment</option>

              {experiments.map((experiment) => (
                <option
                  key={experiment.experimentId}
                  value={experiment.experimentId}
                >
                  #{experiment.experimentId} - {experiment.experimentName}
                </option>
              ))}
            </select>

            {selectedExperiment && (
              <div className="linked-experiment-badge">
                Linked to: {selectedExperiment.experimentName}
              </div>
            )}

            <label>Equipment Type</label>
            <select
              name="equipmentTypeId"
              value={form.equipmentTypeId}
              onChange={handleChange}
              disabled
              required
            >
              <option value="">Select equipment type</option>

              {equipmentTypes.map((type) => (
                <option
                  key={type.equipmentTypeId}
                  value={type.equipmentTypeId}
                >
                  {type.equipmentTypeName || type.name}
                </option>
              ))}
            </select>

            <label>Quantity</label>
            <input
              type="number"
              min="1"
              name="quantity"
              value={form.quantity}
              onChange={handleChange}
              required
            />

            <label>Allow Substitute</label>
            <select
              name="allowSubstitute"
              value={form.allowSubstitute}
              onChange={handleChange}
            >
              <option value="true">Allow substitute equipment</option>
              <option value="false">Do not allow substitute</option>
            </select>

            <label>Min Acceptable Efficiency (%)</label>
            <input
              type="number"
              min="0"
              max="100"
              step="0.01"
              name="minAcceptableEfficiency"
              value={form.minAcceptableEfficiency}
              onChange={handleChange}
              required
            />

            <label>Note</label>
            <textarea
              name="note"
              value={form.note}
              onChange={handleChange}
              placeholder="Optional note..."
              rows={4}
            />
          </div>

          <div className="requirement-form-card">
            <h3>Preview</h3>

            <div className="requirement-preview">
              <div>
                <span>Selected Experiment</span>
                <strong>
                  {selectedExperiment
                    ? selectedExperiment.experimentName
                    : "Not selected"}
                </strong>
              </div>

              {selectedExperiment && (
                <>
                  <div>
                    <span>Experiment Status</span>
                    <strong>{selectedExperiment.status || "-"}</strong>
                  </div>

                  <div>
                    <span>Experiment Priority</span>
                    <strong>{selectedExperiment.priority || "-"}</strong>
                  </div>
                </>
              )}

              <div>
                <span>Selected Equipment Type</span>
                <strong>
                  {selectedEquipmentType
                    ? selectedEquipmentType.equipmentTypeName ||
                      selectedEquipmentType.name
                    : "Not selected"}
                </strong>
              </div>

              <div>
                <span>Quantity</span>
                <strong>{form.quantity}</strong>
              </div>

              <div>
                <span>Substitute</span>
                <strong>
                  {form.allowSubstitute === "true"
                    ? "Allowed"
                    : "Not allowed"}
                </strong>
              </div>

              <div>
                <span>Min Efficiency</span>
                <strong>{form.minAcceptableEfficiency}%</strong>
              </div>
            </div>

            <div className="form-actions">
              <button
                type="button"
                className="cancel-btn"
                onClick={() => navigate("/equipment-requirements")}
              >
                Cancel
              </button>

              <button type="submit" className="save-btn" disabled={saving}>
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}