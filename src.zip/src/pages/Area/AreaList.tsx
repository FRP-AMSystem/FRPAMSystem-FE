import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Map, Pencil, Plus, Search, Trash2, X } from "lucide-react";
import DashboardLayout from "../../layouts/DashboardLayout";
import { createArea, deleteArea, getAreas, updateArea, type Area } from "../../services/areaService";
import "./AreaList.css";

type Role = "Manager" | "Researcher" | "Technician" | "Student";

function getErrorMessage(error: unknown): string {
    if (typeof error === "object" && error !== null && "response" in error) {
        const response = (error as { response?: { data?: { message?: string; error?: string; title?: string } } }).response;
        return response?.data?.message || response?.data?.error || response?.data?.title || "Unable to complete the request.";
    }
    return error instanceof Error ? error.message : "Unable to complete the request.";
}

export default function AreaList() {
    const role = (localStorage.getItem("role") || "Student") as Role;
    const canManage = role === "Manager";
    const [areas, setAreas] = useState<Area[]>([]);
    const [keyword, setKeyword] = useState("");
    const [appliedKeyword, setAppliedKeyword] = useState("");
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [deletingId, setDeletingId] = useState<number | null>(null);
    const [error, setError] = useState("");
    const [dialogOpen, setDialogOpen] = useState(false);
    const [editing, setEditing] = useState<Area | null>(null);
    const [areaName, setAreaName] = useState("");
    const [description, setDescription] = useState("");

    const loadAreas = useCallback(async () => {
        try {
            setLoading(true);
            setError("");
            setAreas(await getAreas({ keyword: appliedKeyword || undefined, page: 1, size: 200 }));
        } catch (loadError) {
            setError(getErrorMessage(loadError));
            setAreas([]);
        } finally {
            setLoading(false);
        }
    }, [appliedKeyword]);

    useEffect(() => { void loadAreas(); }, [loadAreas]);

    const openCreate = () => {
        setEditing(null);
        setAreaName("");
        setDescription("");
        setDialogOpen(true);
    };

    const openEdit = (area: Area) => {
        setEditing(area);
        setAreaName(area.areaName);
        setDescription(area.description || "");
        setDialogOpen(true);
    };

    const closeDialog = () => { if (!saving) setDialogOpen(false); };

    const handleSubmit = async (event: FormEvent) => {
        event.preventDefault();
        const name = areaName.trim();
        if (!name) { setError("Area name is required."); return; }

        try {
            setSaving(true);
            setError("");
            const payload = { areaName: name, description: description.trim() || null };
            if (editing) await updateArea(editing.areaId, payload);
            else await createArea(payload);
            setDialogOpen(false);
            await loadAreas();
        } catch (submitError) {
            setError(getErrorMessage(submitError));
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (area: Area) => {
        if (!window.confirm(`Delete area "${area.areaName}"?`)) return;
        try {
            setDeletingId(area.areaId);
            setError("");
            await deleteArea(area.areaId);
            setAreas((current) => current.filter((item) => item.areaId !== area.areaId));
        } catch (deleteError) {
            setError(getErrorMessage(deleteError));
        } finally {
            setDeletingId(null);
        }
    };

    return (
        <DashboardLayout>
            <div className="area-page">
                <header className="area-header">
                    <div><p>Dashboard / Areas</p><h1>Areas</h1><span>Manage geographical areas used to group forestry land resources.</span></div>
                    {canManage && <button onClick={openCreate}><Plus size={18} /> Add Area</button>}
                </header>

                <section className="area-filter">
                    <div><Search size={18} /><input value={keyword} onChange={(event) => setKeyword(event.target.value)} onKeyDown={(event) => event.key === "Enter" && setAppliedKeyword(keyword.trim())} placeholder="Search areas..." /></div>
                    <button onClick={() => setAppliedKeyword(keyword.trim())}>Search</button>
                    {(keyword || appliedKeyword) && <button className="secondary" onClick={() => { setKeyword(""); setAppliedKeyword(""); }}>Clear</button>}
                </section>

                {error && <div className="area-error">{error}</div>}

                <section className="area-card">
                    <div className="area-card-title"><div><h2>Area List</h2><p>{areas.length} areas</p></div><Map size={22} /></div>
                    {loading ? <div className="area-state">Loading areas...</div> : areas.length === 0 ? <div className="area-state">No areas found.</div> : (
                        <div className="area-table-wrap"><table><thead><tr><th>ID</th><th>Area name</th><th>Description</th><th>Created</th><th>Actions</th></tr></thead><tbody>
                            {areas.map((area) => <tr key={area.areaId}><td>#{area.areaId}</td><td><strong>{area.areaName}</strong></td><td>{area.description || "No description"}</td><td>{area.createdAt ? new Date(area.createdAt).toLocaleDateString("vi-VN") : "-"}</td><td><div className="area-actions">{canManage ? <><button title="Edit" onClick={() => openEdit(area)}><Pencil size={16} /></button><button className="danger" disabled={deletingId === area.areaId} title="Delete" onClick={() => void handleDelete(area)}><Trash2 size={16} /></button></> : <span>View only</span>}</div></td></tr>)}
                        </tbody></table></div>
                    )}
                </section>

                {dialogOpen && <div className="area-overlay" onMouseDown={(event) => event.target === event.currentTarget && closeDialog()}><form className="area-dialog" onSubmit={handleSubmit}>
                    <div className="area-dialog-head"><h2>{editing ? "Edit Area" : "Create Area"}</h2><button type="button" onClick={closeDialog}><X size={19} /></button></div>
                    <label>Area name<input value={areaName} onChange={(event) => setAreaName(event.target.value)} disabled={saving} required /></label>
                    <label>Description<textarea value={description} onChange={(event) => setDescription(event.target.value)} disabled={saving} rows={5} /></label>
                    <div className="area-dialog-actions"><button type="button" className="secondary" onClick={closeDialog} disabled={saving}>Cancel</button><button type="submit" disabled={saving}>{saving ? "Saving..." : editing ? "Save Changes" : "Create Area"}</button></div>
                </form></div>}
            </div>
        </DashboardLayout>
    );
}
