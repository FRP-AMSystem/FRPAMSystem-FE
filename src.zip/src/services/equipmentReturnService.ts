import api from "./api";
import type {
  EquipmentReturnMineRequest,
  EquipmentReturnQuery,
  EquipmentReturnRecord,
  RejectEquipmentReturnRequest,
} from "../types/equipmentReturn";

function validateId(id: number, fieldName: string): void {
  if (!Number.isInteger(id) || id <= 0) {
    throw new Error(`${fieldName} is invalid.`);
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function cleanParams(params: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(params).filter(
      ([, value]) => value !== undefined && value !== null && value !== ""
    )
  );
}

function unwrapResponse<T>(payload: unknown): T {
  if (!isRecord(payload)) return payload as T;

  if ("data" in payload && payload.data !== undefined) {
    return unwrapResponse<T>(payload.data);
  }

  if ("result" in payload && payload.result !== undefined) {
    return unwrapResponse<T>(payload.result);
  }

  return payload as T;
}

function normalizeList<T>(payload: unknown): T[] {
  if (Array.isArray(payload)) return payload as T[];

  if (!isRecord(payload)) return [];

  for (const key of ["items", "data", "result", "records"]) {
    const value = payload[key];

    if (Array.isArray(value)) {
      return value as T[];
    }

    if (isRecord(value)) {
      const nested = normalizeList<T>(value);

      if (nested.length > 0) {
        return nested;
      }
    }
  }

  return [];
}

export async function getEquipmentReturns(
  query: EquipmentReturnQuery = {}
): Promise<EquipmentReturnRecord[]> {
  const response = await api.get("/EquipmentReturns", {
    params: cleanParams({
      AllocationEquipmentDetailId: query.allocationEquipmentDetailId,
      EquipmentInstanceId: query.equipmentInstanceId,
      ReturnedBy: query.returnedBy,
      ReceivedBy: query.receivedBy,
      Status: query.status,
      IsDamaged: query.isDamaged,
      ReturnDateFrom: query.returnDateFrom,
      ReturnDateTo: query.returnDateTo,
      Page: query.page,
      Size: query.size,
    }),
  });

  return normalizeList<EquipmentReturnRecord>(response.data);
}

export async function getEquipmentReturnById(
  id: number
): Promise<EquipmentReturnRecord> {
  validateId(id, "Equipment return ID");

  const response = await api.get(`/EquipmentReturns/${id}`);

  return unwrapResponse<EquipmentReturnRecord>(response.data);
}

export async function submitMyEquipmentReturn(
  allocationEquipmentDetailId: number,
  payload: EquipmentReturnMineRequest
): Promise<EquipmentReturnRecord> {
  validateId(
    allocationEquipmentDetailId,
    "Allocation equipment detail ID"
  );

  const response = await api.patch(
    `/EquipmentReturns/mine/${allocationEquipmentDetailId}/return`,
    payload
  );

  return unwrapResponse<EquipmentReturnRecord>(response.data);
}

export async function confirmEquipmentReturn(
  id: number
): Promise<void> {
  validateId(id, "Equipment return ID");

  await api.patch(`/EquipmentReturns/${id}/confirm`);
}

export async function rejectEquipmentReturn(
  id: number,
  payload: RejectEquipmentReturnRequest
): Promise<void> {
  validateId(id, "Equipment return ID");

  await api.patch(
    `/EquipmentReturns/${id}/reject`,
    payload
  );
}