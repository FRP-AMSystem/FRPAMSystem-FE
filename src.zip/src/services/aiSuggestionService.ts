import api from "./api";
import type {
  AISuggestionInput,
  AISuggestionPlan,
  AISuggestionResponse,
  AllocatedEquipmentItem,
  AllocatedHumanItem,
  AllocatedLandItem,
  ConstraintReport,
  FitnessBreakdown,
  TimelinePhaseItem,
} from "../types/aiSuggestion";

export interface OptimizationSettings {
  // These fields mirror the BE OptimizationSettings contract.
  populationSize?: number;
  generationCount?: number;
  mutationRate?: number;
  initialMutationRate?: number;
  finalMutationRate?: number;
  crossoverRate?: number;
  eliteCount?: number;
  tournamentSize?: number;
  topSuggestionCount?: number;
  landWeight?: number;
  humanWeight?: number;
  equipmentWeight?: number;
  maintenanceWeight?: number;
  softConstraintPenalty?: number;
  maximumBonus?: number;

  // Kept as optional compatibility fields for older UI code. They are NOT
  // sent to the BE because the current BE does not define them.
  maxScheduleShiftDays?: number;
  scheduleWeight?: number;
  penaltyWeight?: number;
  bonusWeight?: number;
  hardConstraintPenalty?: number;
}

export const DEFAULT_OPTIMIZATION_SETTINGS: OptimizationSettings = {
  populationSize: 100,
  generationCount: 80,
  mutationRate: 0.15,
  initialMutationRate: 0.30,
  finalMutationRate: 0.05,
  crossoverRate: 0.80,
  eliteCount: 10,
  tournamentSize: 5,
  topSuggestionCount: 5,

  // BE expects normalized weights (0..1), not percentage points.
  landWeight: 0.20,
  humanWeight: 0.25,
  equipmentWeight: 0.40,
  maintenanceWeight: 0.15,

  softConstraintPenalty: 5,
  maximumBonus: 5,
};

export interface ApiOptimizationSuggestion {
  rank?: number;
  fitnessScore?: number;
  penaltyScore?: number;
  bonusScore?: number;
  fitnessBreakdown?: FitnessBreakdown;
  constraintReport?: ConstraintReport;
  conflictCount?: number;
  hardViolationCount?: number;
  softViolationCount?: number;
  estimatedCompletionTime?: string;
  allocatedLands?: AllocatedLandItem[];
  allocatedHumans?: AllocatedHumanItem[];
  allocatedEquipment?: AllocatedEquipmentItem[];
  timeline?: TimelinePhaseItem[];
  advantages?: string[];
  disadvantages?: string[];
}

/**
 * Formats ISO date or raw date string to DD/MM/YYYY
 */
function formatDateShort(dateStr?: string | null): string {
  if (!dateStr) return "-";
  const date = new Date(dateStr);
  if (Number.isNaN(date.getTime())) return dateStr;
  return new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

/**
 * Calculates date difference in days
 */
function calculateDiffDays(startDateStr: string, endDateStr: string): number {
  const start = new Date(startDateStr);
  const end = new Date(endDateStr);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 30;
  const diffTime = Math.max(0, end.getTime() - start.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 30;
}

/**
 * Maps raw API suggestion items from the backend solver into the UI plan model.
 */
function mapApiSuggestions(
  rawList: ApiOptimizationSuggestion[],
  input: AISuggestionInput
): AISuggestionPlan[] {
  const baseStart =
    input.experiment.expectStartDate || new Date().toISOString().split("T")[0];
  const baseEnd = input.experiment.expectEndDate || baseStart;
  const totalDays = calculateDiffDays(baseStart, baseEnd);
  const formattedStart = formatDateShort(baseStart);
  const formattedEnd = formatDateShort(baseEnd);

  return rawList.map((item, idx) => {
    const rank = Number(item.rank ?? idx + 1);
    const isTop = rank === 1;
    const fitness = Number(item.fitnessScore ?? 0);
    const penaltyScore = Number(item.penaltyScore ?? 0);
    const bonusScore = Number(item.bonusScore ?? 0);
    const conflictCount = Number(item.conflictCount ?? 0);

    const timeline = Array.isArray(item.timeline) ? item.timeline : [];
    const allocatedLands = Array.isArray(item.allocatedLands)
      ? item.allocatedLands
      : [];
    const allocatedHumans = Array.isArray(item.allocatedHumans)
      ? item.allocatedHumans
      : [];
    const allocatedEquipment = Array.isArray(item.allocatedEquipment)
      ? item.allocatedEquipment
      : [];

    const durationDays = timeline.reduce(
      (max, t) => Math.max(max, Number(t.durationDays ?? 0)),
      totalDays
    );

    const firstStart = timeline[0]?.startDate
      ? formatDateShort(timeline[0].startDate)
      : formattedStart;
    const lastEnd = timeline[timeline.length - 1]?.endDate
      ? formatDateShort(timeline[timeline.length - 1].endDate)
      : formattedEnd;

    const advantages = Array.isArray(item.advantages) ? item.advantages : [];
    const disadvantages = Array.isArray(item.disadvantages)
      ? item.disadvantages
      : [];

    const rationale = [
      ...advantages,
      ...disadvantages.map((d) => (d.startsWith("Notice:") ? d : `Notice: ${d}`)),
    ];

    if (rationale.length === 0) {
      rationale.push(
        `Optimization plan generated by solver with fitness score of ${fitness.toFixed(1)}%.`
      );
    }

    const description =
      advantages.length > 0
        ? advantages.join(". ")
        : `AI optimization plan with fitness score of ${fitness.toFixed(1)}%.`;

    const changesSummary = [
      {
        field: "Timeline",
        from: `${totalDays} Days (${formattedStart} → ${formattedEnd})`,
        to: `${durationDays} Days (${firstStart} → ${lastEnd})`,
      },
      {
        field: "Equipment Allocation",
        from: `${input.equipmentRequirements?.length || 0} types requested`,
        to:
          allocatedEquipment.length > 0
            ? allocatedEquipment
                .map((e) => e.assetCode || e.equipmentTypeName || "Equipment")
                .join(", ")
            : "Standard availability",
      },
      {
        field: "Human Allocation",
        from: `${input.humanRequirements?.length || 0} roles requested`,
        to:
          allocatedHumans.length > 0
            ? allocatedHumans
                .map((h) => h.fullName || h.roleName || "Staff")
                .join(", ")
            : "Standard assignment",
      },
      {
        field: "Land Allocation",
        from: `${input.landRequirements?.length || 0} plot(s) requested`,
        to:
          allocatedLands.length > 0
            ? allocatedLands
                .map((l) => `${l.landCode || "Plot"} (${l.areaSize || 0} m²)`)
                .join(", ")
            : "Standard plot",
      },
    ];

    const experimentPhases =
      timeline.length > 0
        ? timeline.map((t, pIdx) => ({
            phaseName: t.phaseName || `Phase ${pIdx + 1}`,
            phaseDescription: `Optimized execution window (${t.durationDays || 0} days)`,
            phaseOrder: pIdx + 1,
            expectedStartDate: formatDateShort(t.startDate || baseStart),
            expectedEndDate: formatDateShort(t.endDate || baseEnd),
            status: "Planned" as const,
          }))
        : (input.experimentPhases || []).map((p, pIdx) => ({
            phaseName: p.phaseName,
            phaseDescription: p.phaseDescription || null,
            phaseOrder: p.phaseOrder || pIdx + 1,
            expectedStartDate: formatDateShort(p.expectedStartDate || baseStart),
            expectedEndDate: formatDateShort(p.expectedEndDate || baseEnd),
            status: "Planned" as const,
          }));

    const equipmentRequirements =
      allocatedEquipment.length > 0
        ? allocatedEquipment.map((e) => ({
            equipmentTypeId: Number(
              e.allocatedEquipmentTypeId || e.requiredEquipmentTypeId || 0
            ),
            equipmentTypeName:
              e.equipmentTypeName || e.assetCode || "Equipment",
            quantity: 1,
            allowSubstitute: Boolean(e.isSubstitute),
            minAcceptableEfficiency: Math.round(
              Number(e.efficiencyRate ?? 1) * 100
            ),
            note: e.assetCode ? `Assigned unit: ${e.assetCode}` : undefined,
          }))
        : (input.equipmentRequirements || []).map((e) => ({
            equipmentTypeId: e.equipmentTypeId,
            equipmentTypeName: e.equipmentTypeName,
            quantity: e.quantity,
            allowSubstitute: e.allowSubstitute,
            minAcceptableEfficiency: e.minAcceptableEfficiency,
            note: e.note,
          }));

    const humanRequirements =
      allocatedHumans.length > 0
        ? allocatedHumans.map((h) => ({
            roleId: Number(h.roleId || 0),
            roleName: h.fullName || h.roleName || "Personnel",
            quantity: 1,
            requiredSkillId: null,
            requiredSkillName: undefined,
            workingHoursPerDay: 8,
            note: h.fullName ? `Assigned staff: ${h.fullName}` : null,
          }))
        : (input.humanRequirements || []).map((h) => ({
            roleId: h.roleId,
            roleName: h.roleName,
            quantity: h.quantity,
            requiredSkillId: h.requiredSkillId,
            requiredSkillName: h.requiredSkillName,
            workingHoursPerDay: h.workingHoursPerDay,
            note: h.note,
          }));

    const landRequirements =
      allocatedLands.length > 0
        ? allocatedLands.map((l) => ({
            requiredArea: Number(l.areaSize || 0),
            requiredSoilType: l.soilType || null,
            note: l.landCode ? `Assigned plot: ${l.landCode}` : null,
          }))
        : (input.landRequirements || []).map((l) => ({
            requiredArea: l.requiredArea,
            requiredSoilType: l.requiredSoilType,
            note: l.note,
          }));

    return {
      id: `ai-plan-${rank}`,
      rank,
      title: isTop
        ? `Optimal Allocation Candidate (Rank #${rank})`
        : `Alternative Candidate (Rank #${rank})`,
      strategyBadge: isTop
        ? "Recommended (Rank 1)"
        : `Rank #${rank} • Fitness ${fitness.toFixed(1)}%`,
      description,
      fitnessScore: fitness,
      penaltyScore,
      bonusScore,
      fitnessBreakdown: item.fitnessBreakdown,
      constraintReport: item.constraintReport,
      conflictCount,
      estimatedCompletionTime: item.estimatedCompletionTime,
      estimatedDurationDays: durationDays,
      totalResourceScore: Math.round(fitness),
      advantages,
      disadvantages,
      rationale,
      changesSummary,
      allocatedLands,
      allocatedHumans,
      allocatedEquipment,
      timeline,
      experimentPhases,
      equipmentRequirements,
      humanRequirements,
      landRequirements,
    };
  });
}

/**
 * Service function to fetch real AI experiment plan suggestions from the backend optimization API.
 * Calls POST /api/AllocationOptimizations/experiments/{experimentId}/suggestions
 */
const REQUESTED_SUGGESTION_COUNT = 5;
const OPTIMIZATION_TIMEOUT_MS = 180_000;

function normalizeSignatureValue(value: unknown): string {
  if (value === null || value === undefined) return "";

  return String(value)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function normalizeSignatureDate(value?: string | null): string {
  const normalized = normalizeSignatureValue(value);
  if (!normalized) return "";

  // Allocation dates are business dates for candidate identity. Ignore
  // timezone/time-of-day differences that do not change the selected slot.
  if (normalized.includes("t")) return normalized.slice(0, 10);
  if (normalized.includes(" ")) return normalized.split(" ")[0];
  return normalized;
}

function resourceSignature(parts: Array<unknown>): string {
  return parts.map(normalizeSignatureValue).join("|");
}

/**
 * Build the identity of the allocation that is actually visible to the user.
 *
 * IMPORTANT:
 * Do NOT use BE technical IDs, phase IDs, fitness, penalties, bonuses,
 * conflicts, efficiency or other solver metadata here.
 *
 * If Rank #1 and Rank #2 show the same equipment, personnel, land and
 * execution dates, they are the SAME allocation candidate and must collapse
 * into one card even if the BE gave them different internal IDs.
 */
function buildSuggestionSignature(item: ApiOptimizationSuggestion): string {
  const equipment = (Array.isArray(item.allocatedEquipment)
    ? item.allocatedEquipment
    : []
  )
    .map((e) =>
      resourceSignature([
        // assetCode is the concrete equipment visible to the researcher.
        // equipmentTypeName is the visible fallback when assetCode is absent.
        normalizeSignatureValue(e.assetCode) ||
          normalizeSignatureValue(e.equipmentTypeName) ||
          "equipment",
        normalizeSignatureDate(e.startDate),
        normalizeSignatureDate(e.endDate),
      ]),
    )
    .sort();

  const humans = (Array.isArray(item.allocatedHumans)
    ? item.allocatedHumans
    : []
  )
    .map((h) =>
      resourceSignature([
        normalizeSignatureValue(h.fullName) ||
          normalizeSignatureValue(h.roleName) ||
          "personnel",
        normalizeSignatureDate(h.startDate),
        normalizeSignatureDate(h.endDate),
      ]),
    )
    .sort();

  const lands = (Array.isArray(item.allocatedLands)
    ? item.allocatedLands
    : []
  )
    .map((l) =>
      resourceSignature([
        normalizeSignatureValue(l.landCode) ||
          [
            normalizeSignatureValue(l.areaSize),
            normalizeSignatureValue(l.soilType),
          ]
            .filter(Boolean)
            .join("|") ||
          "land",
        normalizeSignatureDate(l.startDate),
        normalizeSignatureDate(l.endDate),
      ]),
    )
    .sort();

  // Phase names are intentionally NOT part of identity.
  // The same experiment phase can be represented by different BE phase
  // metadata while the researcher sees the same date window.
  const timeline = (Array.isArray(item.timeline) ? item.timeline : [])
    .map((t) =>
      resourceSignature([
        normalizeSignatureDate(t.startDate),
        normalizeSignatureDate(t.endDate),
      ]),
    )
    .sort();

  return JSON.stringify({
    equipment,
    humans,
    lands,
    timeline,
  });
}

function selectUniqueSuggestions(
  rawList: ApiOptimizationSuggestion[],
  limit: number,
): ApiOptimizationSuggestion[] {
  const unique: ApiOptimizationSuggestion[] = [];
  const signatures = new Set<string>();

  for (const item of rawList) {
    const signature = buildSuggestionSignature(item);

    if (signatures.has(signature)) {
      console.warn(
        "AI solver returned a duplicate allocation candidate; FE removed it.",
        { rank: item.rank, signature },
      );
      continue;
    }

    signatures.add(signature);
    unique.push(item);

    if (unique.length >= limit) break;
  }

  return unique;
}

/**
 * Keep the ordering semantics exposed by the BE response:
 * hard violations ASC, fitness DESC, soft violations ASC.
 */
function sortAndRerankSuggestions(
  rawList: ApiOptimizationSuggestion[],
): ApiOptimizationSuggestion[] {
  return [...rawList]
    .sort((a, b) => {
      const hardDiff =
        Number(a.hardViolationCount ?? 0) - Number(b.hardViolationCount ?? 0);
      if (hardDiff !== 0) return hardDiff;

      const fitnessDiff =
        Number(b.fitnessScore ?? 0) - Number(a.fitnessScore ?? 0);
      if (fitnessDiff !== 0) return fitnessDiff;

      const softDiff =
        Number(a.softViolationCount ?? 0) - Number(b.softViolationCount ?? 0);
      if (softDiff !== 0) return softDiff;

      return Number(a.conflictCount ?? 0) - Number(b.conflictCount ?? 0);
    })
    .map((item, index) => ({ ...item, rank: index + 1 }));
}

function toBackendSettings(settings: OptimizationSettings): OptimizationSettings {
  return {
    populationSize: Math.max(
      20,
      Math.min(1000, Number(settings.populationSize ?? 100)),
    ),
    generationCount: Math.max(
      1,
      Math.min(5000, Number(settings.generationCount ?? 80)),
    ),
    mutationRate: Number(settings.mutationRate ?? 0.15),
    initialMutationRate: Number(settings.initialMutationRate ?? 0.30),
    finalMutationRate: Number(settings.finalMutationRate ?? 0.05),
    crossoverRate: Number(settings.crossoverRate ?? 0.80),
    eliteCount: Number(settings.eliteCount ?? 10),
    tournamentSize: Number(settings.tournamentSize ?? 5),
    topSuggestionCount: REQUESTED_SUGGESTION_COUNT,
    landWeight: Number(settings.landWeight ?? 0.20),
    humanWeight: Number(settings.humanWeight ?? 0.25),
    equipmentWeight: Number(settings.equipmentWeight ?? 0.40),
    maintenanceWeight: Number(settings.maintenanceWeight ?? 0.15),
    softConstraintPenalty: Number(settings.softConstraintPenalty ?? 5),
    maximumBonus: Number(settings.maximumBonus ?? 5),
  };
}

/**
 * One request only. The BE owns the Genetic Algorithm and returns up to five
 * candidates. FE only normalizes/de-duplicates the returned list; it never
 * starts additional GA runs and never clones a candidate.
 */
export async function generateAISuggestions(
  input: AISuggestionInput,
  settings: OptimizationSettings = {},
): Promise<AISuggestionResponse> {
  const experimentId = input.experiment.experimentId;

  if (!experimentId || experimentId <= 0) {
    throw new Error("Experiment ID is required to generate AI suggestions.");
  }

  const backendSettings = toBackendSettings({
    ...DEFAULT_OPTIMIZATION_SETTINGS,
    ...settings,
    topSuggestionCount: REQUESTED_SUGGESTION_COUNT,
  });

  try {
    const response = await api.post(
      `/AllocationOptimizations/experiments/${experimentId}/suggestions`,
      backendSettings,
      { timeout: OPTIMIZATION_TIMEOUT_MS },
    );

    const rawData = response.data?.data ?? response.data;
    const rawList: ApiOptimizationSuggestion[] = Array.isArray(rawData)
      ? rawData
      : Array.isArray(rawData?.suggestions)
        ? rawData.suggestions
        : [];

    if (rawList.length === 0) {
      throw new Error(
        "The optimization solver completed but returned no allocation candidates.",
      );
    }

    // Final FE safety gate: candidates are deduplicated AFTER sorting but
    // BEFORE they are mapped into cards. This guarantees that two BE records
    // representing the same visible allocation can never become Rank #1/#2.
    const uniqueRawSuggestions = selectUniqueSuggestions(
      sortAndRerankSuggestions(rawList),
      REQUESTED_SUGGESTION_COUNT,
    );

    const suggestions = mapApiSuggestions(uniqueRawSuggestions, input).map(
      (suggestion, index) => ({
        ...suggestion,
        id: `ai-plan-${index + 1}`,
        rank: index + 1,
        title:
          index === 0
            ? "Optimal Allocation Candidate (Rank #1)"
            : `Alternative Candidate (Rank #${index + 1})`,
        strategyBadge:
          index === 0
            ? "Recommended (Rank 1)"
            : `Rank #${index + 1} • Fitness ${suggestion.fitnessScore.toFixed(1)}%`,
      }),
    );

    return { suggestions };
  } catch (error: any) {
    if (error?.code === "ECONNABORTED" || error?.message?.includes("timeout")) {
      throw new Error(
        "AI optimization is taking too long. The request was stopped after 3 minutes. Please try again with a smaller population or fewer generations.",
      );
    }

    const status = error?.response?.status;
    if (status) {
      throw new Error(
        `AI optimization failed with status code ${status}. Please check the backend logs and try again.`,
      );
    }

    throw error instanceof Error
      ? error
      : new Error("Failed to generate AI allocation suggestions.");
  }
}
