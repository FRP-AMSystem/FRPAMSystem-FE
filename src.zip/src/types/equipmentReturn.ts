export type EquipmentReturnStatus =
  | "Pending"
  | "Confirmed"
  | "Rejected"
  | "Cancelled"
  | string;

export interface EquipmentReturnRecord {
  equipmentReturnId: number;
  allocationEquipmentDetailId: number;
  equipmentInstanceId?: number | null;
  returnedBy?: number;
  returnedByName?: string | null;
  receivedBy?: number | null;
  receivedByName?: string | null;
  returnDate?: string | null;
  quantity?: number;
  conditionAfter?: string | null;
  isDamaged?: boolean;
  damageDescription?: string | null;
  note?: string | null;
  status?: EquipmentReturnStatus | null;
  confirmedAt?: string | null;
  rejectionReason?: string | null;

  // Optional display fields when the API returns joined data.
  equipmentInstanceName?: string | null;
  assetCode?: string | null;
  serialNumber?: string | null;
  allocatedEquipmentTypeName?: string | null;
  experimentName?: string | null;
  phaseName?: string | null;
}

export interface EquipmentReturnQuery {
  allocationEquipmentDetailId?: number;
  equipmentInstanceId?: number;
  returnedBy?: number;
  receivedBy?: number;
  status?: string;
  isDamaged?: boolean;
  returnDateFrom?: string;
  returnDateTo?: string;
  page?: number;
  size?: number;
}

export interface EquipmentReturnMineRequest {
  conditionAfter?: string | null;
  isDamaged: boolean;
  damageDescription?: string | null;
  note?: string | null;
}

export interface RejectEquipmentReturnRequest {
  rejectionReason?: string | null;
}